class ZoranWebStudio:
    def __init__(self):
        self.projets = []
    def creer_projet(self, nom):
        self.projets.append(nom)
        return f"Projet {nom} créé"
    def lister_projets(self):
        return self.projets

from zwebstudio.core import ZoranWebStudio

studio = ZoranWebStudio()
print(studio.creer_projet("Projet1"))
print(studio.lister_projets())

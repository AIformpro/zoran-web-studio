from zwebstudio.core import ZoranWebStudio

def test_creer_projet():
    studio = ZoranWebStudio()
    res = studio.creer_projet("Projet1")
    assert "créé" in res and "Projet1" in studio.projets
